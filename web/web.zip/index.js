const path = require('path');
const fs = require('fs');
const express = require('express');
const session = require('express-session'); // Import express-session
const app = express();
const PORT = 80; // Gunakan port 3000

// Middleware untuk parsing form data
app.use(express.urlencoded({ extended: true }));

// Setup session
app.use(session({
    secret: 'your_secret_key', // Ganti dengan key rahasia
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set to true jika menggunakan HTTPS
}));

// Set view engine ke EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Redirect root ke login
app.get('/', (req, res) => {
    res.redirect('/login');
});

// Route untuk menampilkan halaman login (GET)
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

// Route untuk menangani login (POST)
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Baca database user dari file JSON
    const users = JSON.parse(fs.readFileSync(path.join(__dirname, 'database', 'user.json'), 'utf-8'));

    // Cari user yang cocok
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        // Simpan username di session
        req.session.username = user.username;

        // Redirect ke /nokos setelah login
        res.redirect('/nokos');
    } else {
        res.send('Login gagal! Username atau password salah.');
    }
});

// Route untuk menampilkan halaman nokos (GET)
app.get('/nokos', (req, res) => {
    // Cek apakah user sudah login
    if (req.session.username) {
        // Render halaman nokos.ejs dengan username
        res.render('nokos', { username: req.session.username });
    } else {
        // Jika belum login, redirect ke login
        res.redirect('/login');
    }
});

// Mulai server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
